<?php
require_once "Zend/Loader.php";
Zend_Loader::registerAutoload();
/**
 * Setup controller
 */
$frontController = Zend_Controller_Front::getInstance();
$frontController->setControllerDirectory('./application/controllers');
$frontController->throwExceptions(true);
$frontController->dispatch();