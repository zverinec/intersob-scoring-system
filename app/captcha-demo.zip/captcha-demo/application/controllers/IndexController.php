<?php
class IndexController extends Zend_Controller_Action
{
    public function indexAction()
    {
        $captcha = new Zend_Captcha_Figlet(array(
            'name' => 'foo',
            'wordLen' => 6,
        ));
        $id = $captcha->generate();

        $this->view->captcha = $captcha->render($this->view);
        $this->view->captchaText = $captcha->getWord();

    }

    public function formAction()
    {
        $form = new Zend_Form();
        $element = new Zend_Form_Element_Captcha('foo', array(
            'label' => "Please verify you're a human",
            'captcha' => array(
                'captcha' => 'Figlet',
                'wordLen' => 6,
        ),
        ));
        $form->addElement($element);

        $this->view->msg = '';
        $this->view->form = $form;
        if ($this->getRequest()->isPost())
        {
            if (!$form->isValid($this->getRequest()->getParams())) {
                //not valid
                $this->view->msg = 'Captch Error';
            } else {
                $this->view->msg  = 'Captcha OK';
            }
        }

    }
}